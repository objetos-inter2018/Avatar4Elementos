import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Niñito here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Avatar extends Actor
{
    /**
     * Act - do whatever the Niñito wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        keys();
        catchElements();
        catchBonus();
        catchEnemy();
    }  
    public void keys()
    {
        if(Greenfoot.isKeyDown("left"))
        {
            if(this.getX()>35){
                this.setLocation(this.getX()-5,this.getY());
                this.setImage("Aang (1).png");
            }
            else
                this.setImage("Aang-PNG-Transparent-Image (1).png");
        }
        else if(Greenfoot.isKeyDown("right"))
        {
            if(this.getX()<565)
                this.setLocation(this.getX()+5, this.getY());
            this.setImage("Aang (1).png");
        }
        else
            this.setImage("Aang-PNG-Transparent-Image (1).png");            
        if(Greenfoot.isKeyDown("up"))
        {
            this.setLocation(this.getX(),this.getY()-50);
            Greenfoot.delay(1);
            this.setLocation(this.getX(),this.getY()+50);
        }
    }
    /**
     * 
     */
    public void catchElements()
    {
        if(this.isTouching(Water.class)){
            this.removeTouching(Water.class);    
            Nivel1 n1 = new Nivel1();
            Nivel2 n2 = new Nivel2();
            Nivel3 n3 = new Nivel3();
            if(this.getWorld() == n1)
            {
                Nivel1 w1 = (Nivel1)this.getWorld();
                w1.decreaseWater();
            } else if(this.getWorld() == n2)
                    {
                        Nivel2 w2 = (Nivel2)this.getWorld();
                        w2.decreaseWater();
                    }
                    else if(this.getWorld() == n3)
                        {
                            Nivel3 w3 = (Nivel3)this.getWorld();
                            w3.decreaseWater();
                        }
        }
        if(this.isTouching(Earth.class)){
            this.removeTouching(Earth.class);
            Nivel1 n1 = new Nivel1();
            Nivel2 n2 = new Nivel2();
            Nivel3 n3 = new Nivel3();
            System.out.println(this.getWorld());
            System.out.println(n1);
            if(this.getWorld() == n1)
            {
                n1 = (Nivel1)this.getWorld();
                n1.decreaseEarth();
            } else if(this.getWorld() == n2)
                    {
                        Nivel2 w2 = (Nivel2)this.getWorld();
                        w2.decreaseEarth();
                    }
                    else if(this.getWorld() == n3)
                        {
                            Nivel3 w3 = (Nivel3)this.getWorld();
                            w3.decreaseEarth();
                        }
        }
        if(this.isTouching(Air.class)){
            this.removeTouching(Air.class);
            Nivel1 w = (Nivel1)this.getWorld();
            w.decreaseAir();
        }
        if(this.isTouching(Fire.class)){
            this.removeTouching(Fire.class);
            Nivel1 w = (Nivel1)this.getWorld();
            w.decreaseFire();
        }
    }
    public void catchBonus()
    {
        if(this.isTouching(Quick.class)){
            this.removeTouching(Quick.class);
        }
        if(this.isTouching(Reduction.class)){
            this.removeTouching(Reduction.class);
            Nivel1 w = (Nivel1)this.getWorld();
            w.decreaseElements();
        }
        if(this.isTouching(LifePlus.class)){
            this.removeTouching(LifePlus.class);
            Nivel1 w = (Nivel1)this.getWorld();
            w.increaseLife();
        }
    }
    public void catchEnemy()
    {
        if(this.isTouching(Magic.class)){
            this.removeTouching(Magic.class);
            Nivel1 w = (Nivel1)this.getWorld();
            w.increaseElements();
        }
        if(this.isTouching(Bomb.class)){
            Nivel1 w = (Nivel1)this.getWorld();
            w.removeLife();
        }
        if(this.isTouching(Ray.class)){
            this.removeTouching(Ray.class);
            Nivel1 w = (Nivel1)this.getWorld();
            w.decreaseLife();
        }
    }
}