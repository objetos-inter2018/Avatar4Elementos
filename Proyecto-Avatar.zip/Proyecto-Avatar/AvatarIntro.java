import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AvatarIntro here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AvatarIntro extends World
{

    /**
     * Constructor for objects of class AvatarIntro.
     * 
     */
    ButtonPrueba b;
    public AvatarIntro()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        b = new ButtonPrueba();
        this.addObject(b, 300, 200);
    }
}
